from prettytable import PrettyTable

class ConfusionMatrix:
    def __init__(self, classes_set):
        self.classes = classes_set
        self.matrix = {}
        for clazz in self.classes:
            self.matrix[clazz] = {}
            for subClass in self.classes:
                self.matrix[clazz][subClass] = 0
    
    def generateMatrix(self, obtained_results, expected_results):
        for i in range(len(expected_results)):
            self.matrix[expected_results[i]][obtained_results[i]] += 1    

    def getMatrix(self):
        return self.matrix 

    def getClasses(self):
        return list(self.classes)

    def __str__(self):
        output = PrettyTable()
        field_names = ['']
        for clazz in self.classes:
            field_names.append(clazz)
        output.field_names = field_names

        items = field_names[1:]
        for clazz in items:
            line = [clazz]
            for subClass in items:
                line.append(self.matrix[clazz][subClass])
            output.add_row(line)
        
        labeled_output = PrettyTable()
        labeled_output.field_names = ['', 'Prediction']
        labeled_output.add_row(['\n\n\nConfusion matrix', output.__str__()])
   
        return labeled_output.__str__()
