from prettytable import PrettyTable
from statistics_calculator import StatisticsCalculator
from confusion_matrix import ConfusionMatrix
from knn import KNN
import sys
import random

def file_test_reader(file_name, test_percentage):
    with open(file_name) as file:
        lines = file.read().splitlines()
    
    total_lines = len(lines)
    index_set =  {x for x in range(total_lines)}
    
    total_test = int(total_lines * test_percentage)

    test_indexes = set(random.sample(range(total_lines), total_test))
    training_indexes = index_set - test_indexes

    test_data = []
    training_data = []
    classes_set = set()

    for index in test_indexes:
        list = lines[index].strip().split(',')
        test_data.append([])
        for i in range(len(list) - 1):
            test_data[-1].append(float(list[i]))
        test_data[-1].append(list[-1])
        classes_set.add(list[-1])
    
    for index in training_indexes:
        list = lines[index].strip().split(',')
        training_data.append([])
        for i in range(len(list) - 1):
            training_data[-1].append(float(list[i]))
        training_data[-1].append(list[-1])
        classes_set.add(list[-1])
    
    test_file = open('test_file', 'w')
    for data in test_data:
        test_file.write(str(data)[1:-1] + '\n')
    
    training_file = open('training_file', 'w')
    for data in training_data:
        training_file.write(str(data)[1:-1] + '\n')

    return [training_data, test_data, classes_set]

def write_all_statistics_table(all_statistics):
    output = PrettyTable()
    header = ['', 'Classes data', 'General accuracy']
    output.field_names = header
    for k in all_statistics:
        table = PrettyTable()
        inner_header = ['', 'Recall', 'Specificity', 'Precision', 'F-Score', 'Accuracy']
        table.field_names = inner_header
        
        classes_rating = all_statistics[k].get_classes_ratings()
        for clazz in classes_rating:
            row = []
            row.append(clazz['name'])
            row.append('{:.3f}'.format(clazz['truthy_positive']))
            row.append('{:.3f}'.format(clazz['truthy_negative']))
            row.append('{:.3f}'.format(clazz['precision']))
            row.append('{:.3f}'.format(clazz['f_score']))
            row.append('{:.3f}'.format(clazz['accuracy']))
            table.add_row(row)
        
        line = [str(k), table, '{:.3f}'.format(all_statistics[k].calculate_overral_accuracy())]
        output.add_row(line)
    print(output)

def main():
    if len(sys.argv) < 4:
        print('Invalid number of arguments. Aborting...')
        print('Inform: \n 1 - File path \n 2 - Test percentage \n 3 - K value')
        print('Ex: python3 main.py spambase/spambase.data 0.1 1 3 5 7 9 \n')
        sys.exit()
    data = file_test_reader(sys.argv[1], float(sys.argv[2]))
    knn = KNN(data[0])
    k_test = sys.argv[3:]
    for index, k in enumerate(k_test):
        k_test[index] = int(k)
    
    best_k = -1
    best_accuracy = -1
    all_statistics = {}
    for k in k_test:
        print('\n\n------------- TESTING FOR K = ' + str(k) + '----------------------\n\n')
        knn_result = knn.run(data[1], k)
        expected_results = []
        for single_data in data[1]:
            expected_results.append(single_data[-1])
        
        confusion_matrix = ConfusionMatrix(data[2])
        confusion_matrix.generateMatrix(knn_result, expected_results)
        print(confusion_matrix)

        statistics_calculator = StatisticsCalculator(confusion_matrix)

        accuracy = statistics_calculator.calculate_overral_accuracy()
        if accuracy >= best_accuracy:
            best_accuracy = accuracy
            best_k = k

        all_statistics[k] = statistics_calculator

        print('\n\n------------- END TESTING FOR K = ' + str(k) + '----------------------\n\n')

    write_all_statistics_table(all_statistics)

    print('K of best accuracy: ' + str(best_k))
    print('Best accuracy: ' + '{:.3f}'.format(best_accuracy))

if __name__ == '__main__':
    main()