class StatisticsCalculator:
    def __init__(self, confusion_matrix):
        self.classes = confusion_matrix.getClasses()
        self.matrix = confusion_matrix.getMatrix()

        self.classes_ratings = []

        for clazz in self.classes:
            truthy_positive = self.calculate_truthy_positive(clazz)
            falsy_negative = self.calculate_falsy_negative(clazz)
            falsy_positive = self.calculate_falsy_positive(clazz)
            truthy_negative = self.calculate_truthy_negative(clazz)

            try:
                truthy_positive_rate = truthy_positive / \
                    (truthy_positive + falsy_negative)
            except ZeroDivisionError:
                truthy_positive_rate = 0

            try:
                truthy_negative_rate = truthy_negative / \
                    (truthy_negative + falsy_positive)
            except ZeroDivisionError:
                truthy_negative_rate = 0

            total = truthy_positive + falsy_negative + falsy_positive + truthy_negative

            if truthy_negative + truthy_positive != 0:
                accuracy = (truthy_negative + truthy_positive)/total
            else:
                accuracy = 'N/A'

            try:
                precision = truthy_positive / \
                    (truthy_positive + falsy_positive)
            except ZeroDivisionError:
                precision = 'N/A'

            f_score = 'N/A'
            try:
                if precision != 'N/A':
                    f_score = 2 * (truthy_positive_rate * precision) / \
                        (truthy_positive_rate + precision)
            except ZeroDivisionError:
                f_score = 'N/A'

            class_rating = {'name': clazz, 'truthy_positive': truthy_positive_rate,
                            'truthy_negative': truthy_negative_rate, 'accuracy': accuracy, 'precision': precision, 'f_score': f_score}
            self.classes_ratings.append(class_rating)

    def calculate_truthy_positive(self, clazz):
        return self.matrix[clazz][clazz]

    def calculate_falsy_negative(self, clazz):
        falsy_negative = 0
        for column in self.matrix:
            if column != clazz:
                falsy_negative += self.matrix[clazz][column]
        return falsy_negative

    def calculate_falsy_positive(self, clazz):
        falsy_positive = 0
        for row in self.matrix:
            if row != clazz:
                falsy_positive += self.matrix[row][clazz]
        return falsy_positive

    def calculate_truthy_negative(self, clazz):
        truthy_negative = 0
        for row in self.matrix:
            for column in self.matrix[row]:
                if row == clazz or column == clazz:
                    continue
                truthy_negative += self.matrix[row][column]
        return truthy_negative

    def calculate_overral_accuracy(self):
        diagonal = 0
        total = 0
        for row in self.matrix:
            for column in self.matrix:
                if row == column:
                    diagonal += self.matrix[row][column]
                total += self.matrix[row][column]
        return diagonal/total

    def get_classes_ratings(self):
        return self.classes_ratings

    def __str__(self):
        output = ''
        for clazz in self.classes_ratings:
            output += '-------------- Class : ' + \
                str(clazz['name']) + ' --------------' + '\n'
            output += 'Truthy positive rate (Recall): ' + \
                '{:.3f}'.format(str(clazz['truthy_positive'])) + '\n'
            output += 'Truthy negative rate (Specificity): ' + \
                '{:.3f}'.format(str(clazz['truthy_negative'])) + '\n'
            output += 'Accuracy: ' + \
                '{:.3f}'.format(str(clazz['accuracy'])) + '\n'
            output += 'Precision: ' + \
                '{:.3f}'.format(str(clazz['precision'])) + '\n'
            output += 'F-Score:  ' + \
                '{:.3f}'.format(str(clazz['f_score'])) + '\n\n'
        output += 'General accuracy: ' + \
            '{:.3f}'.format(str(self.calculate_overral_accuracy()))
        return output