import math

class KNN:
    def __init__(self, data):
        self.data = data
        self.cache = {}

    def euclideanDistance(self, list1, list2):
        result = 0
        for i in range(len(list2) - 1):
            result += (list1[i] - list2[i])**2
        return math.sqrt(result)
    
    def bestNeighbors(self, test, k):
        result = []
        for index, data in enumerate(self.data):
            result.append({'index' : index, 'distance' : self.euclideanDistance(test, data)})
        sorted_result = sorted(result, key=lambda k: k['distance'])
        return sorted_result
    
    def run(self, test, k):
        results = []
        for index, test in enumerate(test):
            try:
                self.cache[index]
                best_neighbors = self.cache[index]
            except KeyError:
                best_neighbors = self.bestNeighbors(test, k)
                self.cache[index] = best_neighbors
            
            best_neighbors = best_neighbors[0:k]
            
            result = {}
            for neighbor in best_neighbors:
                data = self.data[neighbor['index']]
                try:
                    result[data[-1]] += 1
                except KeyError:
                    result[data[-1]] = 1
            
            max_value = -1
            max_key = -1
            
            for (key, value) in result.items():
                if(value > max_value):
                    max_value = value
                    max_key = key
            
            results.append(max_key)

        return results
