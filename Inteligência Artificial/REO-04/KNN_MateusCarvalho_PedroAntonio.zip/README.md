1)apt install python3-pip
2)pip3 install --user prettytable
1)python3 main.py spambase/spambase.data 0.10 1 3 5 7